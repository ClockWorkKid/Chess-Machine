clear all
close all
clc

board=Board
board.movePiece(board,'e2e4')
pause();
board.movePiece(board,'d7d5')
pause();
% board.movePiece(board,'g1f3')
% pause();
% board.movePiece(board,'b8c6')
% pause();
% board.movePiece(board,'f1c4')
% pause();
% board.movePiece(board,'d7d6')
% pause();
% board.movePiece(board,'b1c3')
% pause();
% board.movePiece(board,'c8g4')
% pause();
% board.movePiece(board,'f3e5')
% pause();
% board.movePiece(board,'g4d1')
% pause();
% board.movePiece(board,'c4f7')
% pause();
% board.movePiece(board,'e8e7')
% pause();
% board.movePiece(board,'c3d5')
% pause();