function looping( )

for (i=1:10 && j=1:10)
        fprintf("%d %d\n",i,j);
    end
    
end

