classdef Box
    
    properties
        row;
        column;
        ghuti = Piece;
    end
    
    methods
    end
    
end

